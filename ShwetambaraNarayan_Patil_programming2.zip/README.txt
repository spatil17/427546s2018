Please open Question1.html in a web browser for fractal implementation

Please open Question2.html in a web browser for wheel design implementation
