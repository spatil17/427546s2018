Name :Computer Graphics Final Project Week 3

Shwetambara Narayan Patil

Open the index.html file to view 3 D model of the house. Move along the sides to view the model from different angles.