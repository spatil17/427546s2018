﻿Shwetambara Narayan Patil : Computer Graphics Final Project week 2

There are two files mainly : 
index.html displays 8 Projection types.
3D_transformation.html is my attempt at creating transformation on the cube.
