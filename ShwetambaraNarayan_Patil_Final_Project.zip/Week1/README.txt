Computer Graphics Assignment - 3 

Shwetambara Narayan Patil
index.html contains the logic required for the 2-D transformations viz. the front view , side view, top views. The CSS is in the style.css file.For rotate and shear, enter the values in degrees.