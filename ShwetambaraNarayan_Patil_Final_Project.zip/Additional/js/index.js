var _typeof = typeof Symbol === "function" && typeof Symbol.iterator === "symbol" ? function (obj) { return typeof obj; } : function (obj) { return obj && typeof Symbol === "function" && obj.constructor === Symbol && obj !== Symbol.prototype ? "symbol" : typeof obj; };

var _createClass = function () { function defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } } return function (Constructor, protoProps, staticProps) { if (protoProps) defineProperties(Constructor.prototype, protoProps); if (staticProps) defineProperties(Constructor, staticProps); return Constructor; }; }();

function _possibleConstructorReturn(self, call) { if (!self) { throw new ReferenceError("this hasn't been initialised - super() hasn't been called"); } return call && (typeof call === "object" || typeof call === "function") ? call : self; }

function _inherits(subClass, superClass) { if (typeof superClass !== "function" && superClass !== null) { throw new TypeError("Super expression must either be null or a function, not " + typeof superClass); } subClass.prototype = Object.create(superClass && superClass.prototype, { constructor: { value: subClass, enumerable: false, writable: true, configurable: true } }); if (superClass) Object.setPrototypeOf ? Object.setPrototypeOf(subClass, superClass) : subClass.__proto__ = superClass; }

function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }


var mainColor = '#ffffff';
var secondaryColor = '#C9F0FF';
var bgColor = '#FF4500';
var windowWidth = window.innerWidth;
var windowHeight = window.innerHeight;
var Webgl = function () {
function Webgl(w, h) {
    _classCallCheck(this, Webgl);

    this.meshCount = 0;
    this.meshListeners = [];
    this.renderer = new THREE.WebGLRenderer({ antialias: true, alpha: true });
    this.renderer.setPixelRatio(window.devicePixelRatio);
    this.scene = new THREE.Scene();
    this.camera = new THREE.PerspectiveCamera(50, w / h, 1, 1000);
    this.camera.position.set(0, 0, 10);
    this.dom = this.renderer.domElement;
    this.update = this.update.bind(this);
    this.resize = this.resize.bind(this);
    this.resize(w, h); 
  }
  

  _createClass(Webgl, [{
    key: 'add',
    value: function add(mesh) {
      this.scene.add(mesh);
      if (!mesh.update) return;
      this.meshListeners.push(mesh.update);
      this.meshCount++;
      
    }
    
  }, {
    key: 'update',
    value: function update() {
      var i = this.meshCount;
      while (--i >= 0) {
        this.meshListeners[i].apply(this, null);
        
      }
      this.renderer.render(this.scene, this.camera);
      
    }
    
  }, {
    key: 'resize',
    value: function resize(w, h) {
      this.camera.aspect = w / h;
      this.camera.updateProjectionMatrix();
      this.renderer.setSize(w, h);
      
    }
    
  }]);

  return Webgl;
}();


var webgl = new Webgl(windowWidth, windowHeight);
document.body.appendChild(webgl.dom);


var COLUMN_NUMBER = 34;
var CUBE_SIZE = 3;

var CanvasTextureTool = function CanvasTextureTool(THREE) {
  var _ref = arguments.length > 1 && arguments[1] !== undefined ? arguments[1] : {},
      _ref$width = _ref.width,
      width = _ref$width === undefined ? 256 : _ref$width,
      _ref$height = _ref.height,
      height = _ref$height === undefined ? 256 : _ref$height,
      _ref$onUpdate = _ref.onUpdate,
      onUpdate = _ref$onUpdate === undefined ? function (f) {
    return f;
  } : _ref$onUpdate;

  var canvas = document.createElement('canvas');
  canvas.id = 'canvas-texture';
  canvas.className = 'CanvasTextureTool-canvas';
  canvas.width = width;
  canvas.height = height;

  var ctx = canvas.getContext('2d');

  var texture = false;
  var material = false;
  if (THREE) {
    texture = new THREE.Texture(canvas);
    texture.needsUpdate = true;
    material = new THREE.MeshBasicMaterial({ map: texture, overdraw: true });
  }

  var update = function update() {
    var data = arguments.length > 0 && arguments[0] !== undefined ? arguments[0] : {};

    var props = Object.assign({ width: width, height: height }, (typeof data === 'undefined' ? 'undefined' : _typeof(data)) === 'object' ? data : { data: data });
    onUpdate(ctx, props);
    if (THREE) {
      texture.needsUpdate = true;
    }
  };
  update();

  return {
    update: update,
    canvas: canvas,
    texture: texture,
    material: material
  };
};

var drawCanvasStripes = function drawCanvasStripes(context, props, specificPosFunc) {
  var width = props.width,
      height = props.height,
      increment = props.increment;

  var columnWidth = width / (COLUMN_NUMBER * 0.5);
  context.beginPath();
  context.fillStyle = bgColor;
  context.fillRect(0, 0, width, height);
  context.lineWidth = columnWidth * 0.15;
  context.strokeStyle = mainColor;
  var i = void 0;
  for (i = 0; i <= COLUMN_NUMBER; i++) {
    var dist = columnWidth * i - increment % columnWidth;
    specificPosFunc(dist, columnWidth);
  }
  context.stroke();
};

var Block = function (_THREE$Object3D) {
  _inherits(Block, _THREE$Object3D);

  function Block() {
    _classCallCheck(this, Block);

    var _this = _possibleConstructorReturn(this, (Block.__proto__ || Object.getPrototypeOf(Block)).call(this));

    _this.i = 0.0;
    _this.diagonalStripeTexture = new CanvasTextureTool(THREE, { onUpdate: function onUpdate(context, props) {
        drawCanvasStripes(context, props, function (dist, columnWidth) {
          context.moveTo(-columnWidth, dist);
          context.lineTo(dist, -columnWidth);
        });
      } });
    _this.diagonalReverseStripeTexture = new CanvasTextureTool(THREE, { onUpdate: function onUpdate(context, props) {
        var width = props.width;

        drawCanvasStripes(context, props, function (dist, columnWidth) {
          context.moveTo(width - dist, -columnWidth);
          context.lineTo(width + columnWidth, dist);
        });
      } });
    _this.verticalStripeTexture = new CanvasTextureTool(THREE, { onUpdate: function onUpdate(context, props) {
        var height = props.height;

        drawCanvasStripes(context, props, function (dist) {
          context.moveTo(dist, height);
          context.lineTo(dist, 0);
        });
      } });
    _this.horizontalStripeTexture = new CanvasTextureTool(THREE, { onUpdate: function onUpdate(context, props) {
        var width = props.width;

        drawCanvasStripes(context, props, function (dist) {
          context.moveTo(0, dist);
          context.lineTo(width, dist);
        });
      } });

    _this.materials = [];
    _this.materials.push(_this.horizontalStripeTexture.material);
    _this.materials.push(_this.verticalStripeTexture.material);
    _this.materials.push(_this.diagonalStripeTexture.material);
    _this.materials.push(_this.diagonalReverseStripeTexture.material);
    _this.materials.push(_this.horizontalStripeTexture.material);
    _this.materials.push(_this.verticalStripeTexture.material);

    _this.geometry = new THREE.BoxGeometry(CUBE_SIZE, CUBE_SIZE, CUBE_SIZE, 20, 20);
    _this.material = new THREE.MeshFaceMaterial(_this.materials);
    _this.mesh = new THREE.Mesh(_this.geometry, _this.material);
    _this.mesh.rotation.set(1.52, 0, 0);
    _this.add(_this.mesh);

    _this.floorGeometry = new THREE.PlaneGeometry(CUBE_SIZE + 0.1, CUBE_SIZE + 0.1, 1);
    _this.floorMaterial = new THREE.MeshBasicMaterial({ color: '#FF4500', side: THREE.DoubleSide });
    _this.floor = new THREE.Mesh(_this.floorGeometry, _this.floorMaterial);
    _this.floor.position.set(-0.15, -CUBE_SIZE, 0.2);
    _this.floor.rotation.set(1.52, 0, 0);
    _this.add(_this.floor);

    _this.rotation.set(0.25, 0.7, 0);
    _this.update = _this.update.bind(_this);
    return _this;
  }

  _createClass(Block, [{
    key: 'update',
    value: function update() {
      this.i += 0.25;
      var dist = Math.cos(this.i * 0.2) * 0.1 - 1;
      this.mesh.position.y = dist;
      this.floor.scale.set(dist, dist, dist);
      this.verticalStripeTexture.update({ increment: this.i });
      this.horizontalStripeTexture.update({ increment: this.i });
      this.diagonalStripeTexture.update({ increment: this.i });
      this.diagonalReverseStripeTexture.update({ increment: this.i });
    }
  }]);

  return Block;
}(THREE.Object3D);

webgl.add(new Block());


function onResize() {
  windowWidth = window.innerWidth;
  windowHeight = window.innerHeight;
  webgl.resize(windowWidth, windowHeight);
  
}
window.addEventListener('resize', onResize);
window.addEventListener('orientationchange', onResize);

function _loop() {
  webgl.update();
  requestAnimationFrame(_loop);
}
_loop();