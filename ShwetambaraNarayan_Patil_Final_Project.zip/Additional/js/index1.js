
var ww = window.innerWidth,
	wh = window.innerHeight;

function init(){

	renderer = new THREE.WebGLRenderer({canvas : document.getElementById('scene')});
	renderer.setClearColor(0x000080);
	renderer.setSize(ww,wh);
	renderer.shadowMap.enabled = true;

	scene = new THREE.Scene();

	camera = new THREE.PerspectiveCamera(50, ww/wh, 1, 10000 );
	camera.position.set(0, 350, 500);
	camera.lookAt(new THREE.Vector3(0,0,0));
	scene.add(camera);

	light = new THREE.SpotLight(0xffffff, 1);
	light.position.set( 0, 1500, 0 );
	
	light.castShadow = true;
  
  light.shadow = new THREE.LightShadow( new THREE.PerspectiveCamera( 50, 1, 1200, 2500 ) );
  
  light.shadow.mapSize.width = 1024;
  light.shadow.mapSize.height = 1024;
	scene.add(light);


	createBox();

	renderer.render(scene,camera);

	animate();

};

function createBox(){

	geometry = new THREE.BoxGeometry(100,100,100);
	texture = new THREE.MeshLambertMaterial({color:0xFF4500 });
	cube = new THREE.Mesh(geometry, texture);
	cube.position.y = 150;
	scene.add(cube);

	cube.castShadow = true;

	groundGeometry = new THREE.PlaneBufferGeometry(500, 500);
	texture = new THREE.MeshLambertMaterial({color:0xcccccc });
  ground = new THREE.Mesh(groundGeometry, texture);
  ground.rotation.x = -Math.PI / 2;
  ground.receiveShadow = true;
	scene.add(ground);
};

var counter = 0;
var animate = function () {
	requestAnimationFrame(animate);

	cube.rotation.x += .02;
	cube.rotation.y += .02;
	cube.position.x = Math.sin(counter/100)*150;
	counter++;

	renderer.render(scene, camera);
};

init();