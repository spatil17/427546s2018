Name : Shwetambara Narayan Patil

Feature1.html renders the light and shadow feature.

Feature2.html renders the texture and shadow feature.

I have used Three.js and Codepen for reference.