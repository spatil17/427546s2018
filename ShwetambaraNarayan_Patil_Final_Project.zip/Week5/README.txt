Name : Shwetambara Narayan Patil

I have used Three.js and Codepen for reference.

Click on the screen to see the interior of the house.