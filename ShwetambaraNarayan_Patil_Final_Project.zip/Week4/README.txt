﻿Shwetambara Narayan Patil : Computer Graphics Final Project week 4

There are two files mainly : 
canvas_geometry_cube.html displays a rotating cube.
tween_cube.html is my attempt at creating clickable cube objects.

I have used Three.js for reference.
